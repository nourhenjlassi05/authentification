package com.example.myapp_tp6_retrofit

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

// API service interface
interface ApiService {
    @GET("/Etudiants")
    suspend fun getAll(): Response<MutableList<User>>

    @DELETE("Etudiants/{id}")
    suspend fun deleteEtudiant(@Path("id") userId: Long): Response<Void>

    @PUT("Etudiants/{id}")
    suspend fun updateEtudiant(@Path("id") userId: Long, @Body user: User): Response<Void>


    @POST("Etudiants")
    suspend fun saveEtudiant(@Body user: User): Response<User>
}

// Singleton for the API client
object ApiClient {
    private const val BASE_URL: String = "http://192.168.1.107:8081"
    private val gson: Gson by lazy {
        GsonBuilder().setLenient().create()
    }

    private val httpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            setLevel(HttpLoggingInterceptor.Level.BODY)
        }
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS) // Timeout plus long
            .readTimeout(30, TimeUnit.SECONDS)   // Timeout plus long
            .build()
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var userAdapter: UserAdapter
    private var userList: MutableList<User> = mutableListOf()
    lateinit var boutton : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialiser RecyclerView et l'adaptateur
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        boutton=findViewById(R.id.adduser)

        // Initialiser l'adaptateur avec les actions de suppression et d'édition
        userAdapter = UserAdapter(userList, { user -> deleteUser(user) }, { user -> editUser(user) })
        recyclerView.adapter = userAdapter

        // Fetch data from API
        fetchDataFromApi()

        boutton.setOnClickListener {
            // Créer un AlertDialog pour ajouter un nouvel utilisateur
            val builder = AlertDialog.Builder(this)
            val dialogView = layoutInflater.inflate(R.layout.dialog_edit_user, null)

            val editName = dialogView.findViewById<EditText>(R.id.editName)
            val editAddress = dialogView.findViewById<EditText>(R.id.editAddress)

            builder.setView(dialogView)
                .setPositiveButton("Add") { _, _ ->
                    val newName = editName.text.toString()
                    val newAddress = editAddress.text.toString()

                    if (newName.isNotEmpty() && newAddress.isNotEmpty()) {
                        val newUser = User(id = 0, name = newName, address = newAddress) // L'ID peut être 0, car il sera généré par la base de données
                        addUser(newUser)
                    } else {
                        Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

    }

    private fun fetchDataFromApi() {
        val scope = CoroutineScope(Dispatchers.Main)
        scope.launch {
            try {
                val response = ApiClient.apiService.getAll()
                if (response.isSuccessful && response.body() != null) {
                    val users = response.body()
                    // Convertir en MutableList
                    val userDisplayList = users?.map { user ->
                        User(
                            id = user.id,
                            name = user.name ?: "Unknown",
                            address = user.address ?: "No Address"
                        )
                    }?.toMutableList() ?: mutableListOf()

                    // Passer les données à l'adaptateur
                    userAdapter.updateData(userDisplayList)
                } else {
                    Log.e("API Error", "Code: ${response.code()}, Message: ${response.message()}")
                    Toast.makeText(
                        this@MainActivity,
                        "Error: ${response.code()} - ${response.message()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Log.e("Network Exception", "Message: ${e.message}", e)
                Toast.makeText(
                    this@MainActivity,
                    "Network Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun deleteUser(user: User) {
        val scope = CoroutineScope(Dispatchers.Main)
        scope.launch {
            try {
                val response = ApiClient.apiService.deleteEtudiant(userId = user.id)
                if (response.isSuccessful) {
                    // Mise à jour de la liste des utilisateurs après suppression
                    userList.remove(user)

                    // Rafraîchir la liste dans l'adaptateur
                    userAdapter.updateData(userList)

                    Toast.makeText(this@MainActivity, "User deleted successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Log.e("API Error", "Code: ${response.code()}, Message: ${response.message()}")
                    Toast.makeText(
                        this@MainActivity,
                        "Error: ${response.code()} - ${response.message()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Log.e("Network Exception", "Message: ${e.message}", e)
                Toast.makeText(
                    this@MainActivity,
                    "Error Occurred: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun editUser(user: User) {
        // Créer un AlertDialog pour modifier les informations de l'utilisateur
        val builder = AlertDialog.Builder(this)
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_user, null)

        val editName = dialogView.findViewById<EditText>(R.id.editName)
        val editAddress = dialogView.findViewById<EditText>(R.id.editAddress)

        // Remplir les champs avec les informations existantes
        editName.setText(user.name)
        editAddress.setText(user.address)

        builder.setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newName = editName.text.toString()
                val newAddress = editAddress.text.toString()

                if (newName.isNotEmpty() && newAddress.isNotEmpty()) {
                    val updatedUser = User(user.id, newName, newAddress)
                    updateUser(updatedUser)
                } else {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateUser(user: User) {
        val scope = CoroutineScope(Dispatchers.Main)
        scope.launch {
            try {
                val response = ApiClient.apiService.updateEtudiant(user.id, user)
                if (response.isSuccessful) {
                    // Mettre à jour la liste localement
                    val index = userList.indexOfFirst { it.id == user.id }
                    if (index != -1) {
                        userList[index] = user
                        userAdapter.updateData(userList)
                    }
                    Toast.makeText(this@MainActivity, "User updated successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Error: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Network Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun addUser(user: User) {
        val scope = CoroutineScope(Dispatchers.Main)
        scope.launch {
            try {
                // Vérification des données de l'utilisateur avant l'envoi
                if (user.name.isEmpty() || user.address.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                // Appel API pour ajouter l'utilisateur
                val response = ApiClient.apiService.saveEtudiant(user)

                if (response.isSuccessful) {
                    // Ajouter l'utilisateur localement à la liste
                    response.body()?.let {
                        userList.add(it)  // Ajouter l'utilisateur à la liste locale
                        userAdapter.updateData(userList)  // Mettre à jour le RecyclerView avec userList

                        Toast.makeText(this@MainActivity, "User added successfully", Toast.LENGTH_SHORT).show()
                    } ?: run {
                        Toast.makeText(this@MainActivity, "Failed to add user: Empty response", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // Afficher le code d'erreur pour mieux comprendre la raison de l'échec
                    Toast.makeText(this@MainActivity, "Error: ${response.code()} - ${response.message()}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                // Gérer les erreurs réseau ou autres exceptions
                Toast.makeText(this@MainActivity, "Network Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }


}


