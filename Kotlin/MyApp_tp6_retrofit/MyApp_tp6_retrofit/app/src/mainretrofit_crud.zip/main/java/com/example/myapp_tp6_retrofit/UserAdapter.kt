package com.example.myapp_tp6_retrofit

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class User(
    val id :Long,
    val name: String,
    val address: String
)

class UserAdapter(
    private var userList: MutableList<User>,
    private val onDeleteClick: (User) -> Unit,
    private val onEditeClick:(User) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val userName: TextView = itemView.findViewById(R.id.userName)
        val userAddress: TextView = itemView.findViewById(R.id.userAddress)
        val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)
        val editeButton : ImageButton = itemView.findViewById(R.id.editButton)

        fun bind(user: User) {
            userName.text = user.name
            userAddress.text = user.address

            // Gérer l'événement de suppression
            deleteButton.setOnClickListener {
                onDeleteClick(user)
            }

            editeButton.setOnClickListener(){
                onEditeClick(user)

            }
        }
    }
    // Méthode pour mettre à jour la liste des utilisateurs et rafraîchir l'UI
    fun updateData(newUserList: MutableList<User>) {
        // Vérification si la nouvelle liste est différente de la précédente
        if (newUserList != userList) {
            userList.clear()  // Vider la liste actuelle
            userList.addAll(newUserList)  // Ajouter tous les éléments de la nouvelle liste
            notifyDataSetChanged()  // Rafraîchir la liste
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return UserViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(userList[position])
    }

    override fun getItemCount(): Int = userList.size


}
